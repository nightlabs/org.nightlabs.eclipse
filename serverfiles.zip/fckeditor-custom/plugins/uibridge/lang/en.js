
FCKLang['MyDlgBtnBrowseServer_Image'] = "Select Image...";
FCKLang['MyDlgBtnBrowseServer_Link'] = "Select File...";
FCKLang['MyDlgBtnBrowseServer_Flash'] = "Select Flash File...";
