
FCKLang['MyDlgBtnBrowseServer_Image'] = "Bild auswählen...";
FCKLang['MyDlgBtnBrowseServer_Link'] = "Datei auswählen...";
FCKLang['MyDlgBtnBrowseServer_Flash'] = "Flash Animation auswählen...";
